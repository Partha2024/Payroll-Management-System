# [Payroll-System](https://www.creative-tim.com/product/material-dashboard-angular2)

A payroll system involves everything that has to do with the payment of employees and the filing of ­employment taxes. This includes keeping track of hours, calculating wages, withholding taxes and other deductions, printing and delivering checks and paying employment taxes to the government.

## Versions

[<img src = "https://upload.wikimedia.org/wikipedia/en/thumb/3/30/Java_programming_language_logo.svg/1200px-Java_programming_language_logo.svg.png"  width="30" height="50">](https://www.creative-tim.com/product/material-dashboard)
&nbsp; &nbsp;[<img src = "https://seeklogo.net/wp-content/uploads/2012/03/mysql-vector1.jpg" width="80" height="50">](https://www.creative-tim.com/product/material-dashboard)
